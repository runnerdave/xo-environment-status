import * as React from 'react';

const SpacerRow = () => {
    return (
        <div className="row">
            <div className="col-md-12 row-spacer"/>
        </div>
    );
};

export default SpacerRow;