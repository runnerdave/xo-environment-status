export type ButtonItem = { id: string, title: string };
export type ButtonItemRow = ButtonItem[];
export type ButtonItemMatrix = ButtonItemRow[];